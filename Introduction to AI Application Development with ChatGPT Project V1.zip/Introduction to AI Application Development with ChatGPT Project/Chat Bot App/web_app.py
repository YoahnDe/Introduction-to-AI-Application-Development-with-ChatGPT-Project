# Importing necessary modules
from flask import Flask, request, jsonify
from flask import Flask, render_template, request, url_for
from llama_index import SimpleDirectoryReader, GPTListIndex, LLMPredictor, PromptHelper
from langchain_community.chat_models import ChatOpenAI
import gradio as gr
import sys
import os
import time
#from openai.embeddings_utils import get_embedding, cosine_similarity
import pandas
import openai
import numpy as np
import glob
import datetime

# Setting OpenAI API key
os.environ["OPENAI_API_KEY"] = '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'
openai.api_key = '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'

# Lists to store IP addresses and corresponding timestamps
ips = []
ips_times = []

# Lists to store reference IP addresses and corresponding timestamps
ips_ref = []
ips_times_ref = []

# Importing additional modules
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.chat_models import ChatOpenAI
from langchain.chains.summarize import load_summarize_chain
from langchain.prompts.chat import (
    ChatPromptTemplate,
    SystemMessagePromptTemplate,
    AIMessagePromptTemplate,
    HumanMessagePromptTemplate
)
from langchain.schema import (
    AIMessage,
    HumanMessage,
    SystemMessage
)
from langchain import OpenAI, PromptTemplate, LLMChain
from langchain.text_splitter import CharacterTextSplitter
from langchain.chains.mapreduce import MapReduceChain
from langchain.prompts import PromptTemplate

# Initializing ChatOpenAI instance with specific configuration
llm = ChatOpenAI(temperature=0, model_name="gpt-3.5-turbo")

# Function to obtain embeddings for a given text
def get_embedding(text, model="text-embedding-ada-002"):
    text = text.replace("\n", " ")
    return openai.Embedding.create(input=[text], model=model)['data'][0]['embedding']

# Logic function to process a question and generate a response
def logic(question):
    # Reading embeddings data from a CSV file
    df = pandas.read_csv(f"embd0.csv")

    embd = []
    # Changing the format of the embeddings into a list due to a parsing error
    for r1 in range(len(df.embedding)):
        e1 = df.embedding[r1].split(",")
        for ei2 in range(len(e1)):
            e1[ei2] = float(e1[ei2].strip().replace("[", "").replace("]", ""))
        embd.append(e1)

    df["embedding"] = embd

    bot_message = ""
    # Creating an embedding for the question that's been asked
    product_embedding = get_embedding(question)
    # Finds the relevance of each piece of data in context of the question
    df["similarity"] = df.embedding.apply(lambda x: cosine_similarity(x, product_embedding))
    df.to_csv("embd0.csv")

    # Sorts the text chunks based on how relevant they are to finding the answer to the question
    df2 = df.sort_values("similarity", ascending=False)
    df2.to_csv("embd0.csv")
    df2 = pandas.read_csv("embd0.csv")

    from langchain.docstore.document import Document

    comb = [df2["combined"][0]]
    # Gets the most relevant text chunk
    docs = [Document(page_content=t) for t in comb]

    prompt_template = question + """
    {text}
    """ 
    # Preparing the LLM
    PROMPT = PromptTemplate(template=prompt_template, input_variables=["text"])
    chain = load_summarize_chain(llm, chain_type="stuff", prompt=PROMPT)
    # Formulating an answer
    output = chain.run(docs)
    return output

# Initializing Flask application
app = Flask(__name__)

# Renders the webpage
@app.route("/")
def home():
    return render_template('bot.html')

# Listens to incoming requests
@app.route('/chat', methods=['POST'])
# The function that recieves questions and sends answers from the chatbot
def chat():
    # Receives the question and the previous question that has been asked by the user (needed for follow up questions)
    user_message = request.json['message']
    pm = request.json['pm']

    # Creates a response from the ChatBot
    response = logic(user_message)

    # If the ChatBot isn't able to answer the question, it uses the previous question to make an answer in case it's a follow up question
    if ("sorry" in response.lower()) or ("provide more" in response.lower()) or ("not found" in response.lower()) or ("does not mention" in response.lower()) or ("does not reference" in response.lower()) or ("no information" in response.lower()) or ("not enough information" in response.lower()) or ("unable to provide" in response.lower()) or ("the guidelines do not" in response.lower()):
        response = logic(str(pm + ' ' + user_message))

    # Cleans the response
   
    response = response.replace("<", "").replace(">", "")  # Cleans the response
    return jsonify({'message': response})  # Finally returns the response

# Run the Flask application on localhost:8001 
if __name__ == "__main__":
    app.run(host="localhost", port=8001, debug=True)
